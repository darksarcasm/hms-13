package com.cg.hms.ui;

import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;
import com.cg.hms.service.IUserService;
import com.cg.hms.service.UserServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		System.out.println("Hotel App");

		Scanner scan = new Scanner(System.in);
		PropertyConfigurator.configure("res/log4j.properties");

		int choice = -1;
		int loginAttempts = 0;
		// IHotelService hotelService = new HotelServiceImpl();
		IUserService userService = new UserServiceImpl();
		while (choice != 2 && loginAttempts <= 3) {
			System.out.print("[1]SignUp [2]LogIn [3]Quit >");
			choice = scan.nextInt();

			if (choice == 1) {

				System.out.println("Welcome to the SignUp Page");
				System.out.print("UserName: (random)");
				String userName = scan.next();
				System.out.print("Password: (min 5 char with 1 numeric value)");
				String password = scan.next();
				String role = "Customer";
				System.out.print("Mobile no.: 8097881369");
				String mobileNo = scan.next();
				System.out.print("Phone no.: 24625845/8954125632");
				String phoneNo = scan.next();
				System.out.print("Address: ApnaGhar");
				String address = scan.next();
				System.out.print("Email ID: mail@apna.com");
				String email = scan.next();
				int uid=0;

				User newUser = new User(userName, password, role, mobileNo,
						phoneNo, address, email);

				
				try {
					uid = userService.addUser(newUser);
					
				} catch (HMSException e) {
					System.err.println(e.getMessage());
				}

				if (uid > 0) {
					System.out.println("User: " + newUser.getUserName()
							+ " Registered Successfully.\nYour UserID is "
							+ uid);
				}
			}

			if (choice == 2) {
				System.out.print("UserName? ");
				String userName = scan.next();
				System.out.print("Password? ");
				String password = scan.next();
				loginAttempts++;

				try {
					String role = userService.getRole(userName, password);
					// System.out.println(role);
					if ("admin".equals(role)) {
						AdminConsole ac = new AdminConsole(userName);
						ac.start();
					} else {
						CustomerConsole sc = new CustomerConsole(userName);
						sc.start();
					}
				} catch (HMSException e) {
					System.err.println(e.getMessage());
				}
				
			}
		}

		scan.close();
	}
}
package com.cg.hms.exception;

public class HMSException extends Exception{

		public HMSException(String errMsg){
			super(errMsg);
		}
}

package com.cg.hms.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.hms.bean.User;
import com.cg.hms.dao.IUserDAO;
import com.cg.hms.dao.UserDAOImpl;
import com.cg.hms.exception.HMSException;

public class UserServiceImpl implements IUserService {
	private IUserDAO dao = new UserDAOImpl();

	@Override
	public String getRole(String userName, String password) throws HMSException {
		String role = null;
		User user = dao.getUserByName(userName);
		if (user == null)
			throw new HMSException("No Such UserName");
		else if (!password.equals(user.getPassword()))
			throw new HMSException("Password Mismatch");
		else
			role = user.getRole();
		return role;
	}

	@Override
	public int addUser(User newUser) throws HMSException {
		// TODO Auto-generated method stub
		if(newUser != null && isValidAddEnquiry(newUser)){
			return dao.addUser(newUser);
		}
		return 0;
	}

	@Override
	public int getUserId(String userName) throws HMSException {
		int uid;
		User user = dao.getUserByName(userName);
		if (user == null)
			throw new HMSException("No Such UserName");
		else
			uid = user.getUserId();
		return uid;
	}
	
	@Override
	public boolean isValidAddEnquiry(User newUser) throws HMSException {

		ArrayList<String> validationErrors = new ArrayList<String>();

		if (!isValidUserName(newUser.getUserName())) {
			validationErrors.add("Username Incorrectly Entered."
					+ "\nUsername Must Start with an Alphabet"
					+ "\nUsername Should be of at Least 3 Characters");
		}
		if (!isValidPassword(newUser.getPassword())) {
			validationErrors.add("Weak Password."
					+ "\nPassword Must Contain one Numeric Value"
					+ "\nPassword Length Should be Minimum 5.");
		}
		if (!isValidAddress(newUser.getAddress())) {
			validationErrors.add("Address Incorrectly Entered."
					+ "\nAddress Cannot Be Empty."
					+ "\nAddress Should Contain Minimum 7 Characters.");
		}

		if (!isValidMobileNo(newUser.getMobileNo())) {
			validationErrors.add("Mobile Number Incorrectly Entered."
					+ "\nPlease Enter Digits (0-9) only."
					+ "\nMobile Number Should be of 10 digits and Start with digits 7,8,9");
		}

		if (!isValidPhoneNo(newUser.getPhoneNo())) {
			validationErrors.add("Phone Number Incorrectly Entered."
					+ "\nPlease Enter Digits (0-9) only."
					+ "\nPhone Number Should Be Of 8 OR 10 digits");
		}

		if (!isValidEmail(newUser.getEmail())) {
			validationErrors.add("Email ID Incorrectly Entered."
					+ "\nPlease Enter A Valid Email ID." + "\nEg. abc@xyz.com");
		}

		if (!validationErrors.isEmpty()) {
			throw new HMSException(validationErrors + " ");
		}

		return true;
	}

	private boolean isValidEmail(String email) {

		String ePattern = "^(.+)@(.+)$";

		Pattern pattern = Pattern.compile(ePattern);

		if (pattern.matcher(email).matches()) {
			return true;
		}
		return false;
	}

	private boolean isValidPhoneNo(String phoneNo) {
		String pattern = "[0-9]{8,10}";

		if (phoneNo.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidMobileNo(String mobileNo) {
		String pattern = "[789][0-9]{9}";

		if (mobileNo.matches(pattern)) {
			return true;
		}
		return false;
	}

	private boolean isValidAddress(String address) {
		String aPattern = "[A-Za-z0-9]{7,}"; // "^[a-zA-Z0-9.-\t\n]";
		Pattern pattern = Pattern.compile(aPattern);

		if (pattern.matcher(address).matches()) {
			return true;
		}
		return false;
	}

	private boolean isValidPassword(String password) {
		String dPattern = "[A-Za-z0-9]{3,}";	// "^[a-zA-Z0-9.-\t\n]";
		Pattern pattern = Pattern.compile(dPattern);

		if (pattern.matcher(password).matches()) {
			return true;
		}
		return false;
	}

	private boolean isValidUserName(String userName) {
		String pattern = "[A-Za-z0-9]{3,}";
		if (userName.matches(pattern)) {
			System.out.println();
			return true;
		}
		return false;
	}


	

}

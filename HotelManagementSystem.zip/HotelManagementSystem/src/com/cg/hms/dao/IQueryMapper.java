package com.cg.hms.dao;

public interface IQueryMapper {
	
	
	public final String INSERT_USER="INSERT INTO users VALUES(SEQ_UID.NEXTVAL,?,?,?,?,?,?,?)";
	public final String USER_ID_SEQUENCE="SELECT SEQ_UID.CURRVAL FROM DUAL";

//	Hotel table HOTELID,CITY,HOTELNAME,ADDRESS,DESCRIPTION, AVGRATEPERNIGHT,PHONENO1,PHONENO2,RATING,EMAIL,FAX
	public static final String GET_USER="SELECT * FROM users WHERE userName=?";
	public static final String ADD_HOTEL="INSERT INTO hotel VALUES(?,?,?,?,?,?,?,?,?,?,?)";
	public static final String LIST_HOTELS="SELECT * FROM hotel";
	public static final String DELETE_HOTEL= "DELETE FROM hotel where hotelId=? ";			
	public static final String MODIFY_HOTEL= "UPDATE hotel SET description=? WHERE hotelId=?";	
	public static final String FIND_HOTEL="SELECT * FROM hotel WHERE hotelId=?";
	public static final String ADD_BOOKING="INSERT INTO bookingdetails VALUES(?,?,?,?,?,?,?,?)";
	public static final String FIND_ROOMS="SELECT * FROM roomdetails WHERE hotelId=? ";
	public static final String LIST_ROOMS="SELECT * FROM roomdetails WHERE hotelId=? and roomType=? and availability='Yes'";
	public static final String FIND_AMOUNT="SELECT * FROM roomdetails WHERE roomid=?";
	
	public static final String FIND_USER_ID="SELECT userid FROM users WHERE username=?";
	
	public static final String FIND_USER="SELECT username FROM users WHERE userid IN(SELECT userid FROM bookingdetails WHERE roomId IN(SELECT roomId FROM roomdetails WHERE hotelId=?)) ";
	
	public static final String ADD_ROOM="INSERT INTO roomdetails VALUES(?,?,?,?,?,?)";
	public static final String DELETE_ROOM= "DELETE FROM roomdetails where roomId=? ";	
	public static final String FIND_ROOM_BY_ID="SELECT * FROM roomdetails WHERE roomId=?";
	public static final String MODIFY_ROOM_AVAIL= "UPDATE roomdetails SET availability=? WHERE roomId=?";
	public static final String MODIFY_ROOM_RATE= "UPDATE roomdetails SET pernightrate=? WHERE roomId=?";

	public static final String MODIFY_AVAIL= "UPDATE roomdetails SET availablity='RESERVED' WHERE roomId=?";	
	
	public static final String LIST_BOOKING_DETAILS_BY_ROOMID= "SELECT * FROM bookingdetails WHERE roomid= ?";
	public static final String LIST_BOOKING_DETAILS_BY_HOTELID= "SELECT * FROM bookingdetails WHERE hotelid= ?";
	public static final String LIST_BOOKING_DETAILS= "SELECT * FROM bookingdetails WHERE roomId IN(SELECT roomId FROM roomdetails WHERE hotelId=?)";
	public static final String LIST_BOOKING_DETAILS_BY_DATE= "SELECT * FROM bookingdetails WHERE bookedfrom=?";
	
//	public static final String LIST_RESERVED_BOOKS="SELECT logid,lmsBooks.bcode,studid,title,resvdt FROM lmsRegister INNER JOIN lmsBooks ON lmsRegister.bcode=lmsBooks.bcode WHERE isudt IS NULL";
//	public static final String LIST_ISSUED_BOOKS="SELECT logid,lmsBooks.bcode,studid,title,isudt FROM lmsRegister INNER JOIN lmsBooks ON lmsRegister.bcode=lmsBooks.bcode WHERE isudt IS NOT NULL AND rtndt IS NULL";
//	public static final String FIND_ENTRY="SELECT * FROM lmsRegister WHERE logid=?";
//	public static final String UPDATE_BOOK_STATUS="UPDATE lmsBooks SET status=? WHERE bcode=?";
//	public static final String LOG_RESERVE_BOOK="INSERT INTO lmsRegister(logid,bcode,studid,resvdt) VALUES(logid_seq.nextval,?,?,?)";
//	public static final String LOG_ISSUE_BOOK="UPDATE lmsRegister SET isudt=? WHERE logid=?";
//	public static final String LOG_RETURN_BOOK="UPDATE lmsRegister SET rtndt=? WHERE logid=?";	
}

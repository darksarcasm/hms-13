package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;

public class BookingDaoImpl implements IBookingDao {

	@Override
	public boolean saveBooking(Booking book) throws HMSException {
		boolean bcode = false;
		if (book != null) {
			try (Connection conn = DbUtil.getConnection();
					PreparedStatement st = conn
							.prepareStatement(IQueryMapper.ADD_BOOKING);) {
				st.setInt(1, book.getBookingId());
				st.setInt(2, book.getRoomId());
				st.setInt(3, book.getUserId());
				st.setDate(4, book.getfDate());
				st.setDate(5, book.gettDate());
				st.setInt(6, book.getAdults());
				st.setInt(7, book.getChild());
				st.setDouble(8, book.getAmount());
				int count = st.executeUpdate();

				if (count > 0)
					bcode = true;

			} catch (SQLException e) {
				// log.error(e);
				throw new HMSException("Unable To Save Booking");
			}
		}
		return bcode;
	}

	@Override
	public List<Booking> listBookingDetailsByRoomid(int roomid)
			throws HMSException {
		List<Booking> bookList;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn
						.prepareStatement(IQueryMapper.LIST_BOOKING_DETAILS_BY_ROOMID);) {
			st.setInt(1, roomid);
			ResultSet rs = st.executeQuery();
			bookList = new ArrayList<Booking>();
			Booking book = new Booking();
			while (rs.next()) {
				book.setBookingId(rs.getInt(1));
				book.setRoomId(rs.getInt(2));
				book.setUserId(rs.getInt(3));
				book.setfDate(rs.getDate(4));
				book.setfDate(rs.getDate(5));
				book.setAdults(rs.getInt(6));
				book.setChild(rs.getInt(7));
				book.setAmount(rs.getInt(8));
				bookList.add(book);
			}

		} catch (SQLException e) {
			throw new HMSException("Unable To Fetch book");
		}
		return bookList;
	}

	@Override
	public Room findAmount(int rcode) throws HMSException {
		
			Room room = null;
			try (Connection conn = DbUtil.getConnection();
					PreparedStatement st = conn.prepareStatement(IQueryMapper.FIND_AMOUNT);)  {
				
				st.setInt(1, rcode);
				ResultSet rs = st.executeQuery();			
				if(rs.next()){
					room = new Room();
					room.setPerNightPrice(rs.getDouble(5));	
				}
				
			} catch (SQLException e) {
//				log.error(e);
				throw new HMSException("Unable To Fetch Amount");
			}
			return room;
		
	}

	@Override
	public List<Booking> listBookingsByDate(String date) throws HMSException {
		List<Booking> bookingList;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn.prepareStatement(IQueryMapper.LIST_BOOKING_DETAILS_BY_DATE);)  {
			st.setString(1, date);
			ResultSet rs = st.executeQuery();
			
			bookingList = new ArrayList<Booking>();
			while(rs.next()){
				Booking book = new Booking();
				
				book.setBookingId(rs.getInt("bookingid"));
				book.setRoomId(rs.getInt("roomid"));
				book.setUserId(rs.getInt("userid"));
				bookingList.add(book);
			}
			
		} catch (SQLException e) {
//			log.error(e);
			throw new HMSException("Unable To Fetch username");
		}
		return bookingList;
	}
}

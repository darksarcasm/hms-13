package com.cg.hms.dao;

import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;

public interface IUserDAO {

	User getUserByName(String userName) throws HMSException;
	
	int addUser(User newUser) throws HMSException;
	
}

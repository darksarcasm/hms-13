package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Room;
import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;

public class RoomDAOImpl implements IRoomDAO {

	@Override
	public List<Room> listRoom(int hcode, String rtype) throws HMSException {
		List<Room> roomList;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn.prepareStatement(IQueryMapper.LIST_ROOMS);)  {
			
			st.setInt(1, hcode);
			st.setString(2, rtype);
			ResultSet rs = st.executeQuery();
			roomList = new ArrayList<Room>();		
			while(rs.next()){
				Room room = new Room();
				room.setHotelId(rs.getInt(1));
				room.setRoomId(rs.getInt(2));
				room.setRoomType(rs.getString(4));
				room.setPerNightPrice(rs.getDouble(5));
				room.setAvailable(rs.getString(6));
//				hotel.setStatus(Status.valueOf(rs.getString("status")));	
				roomList.add(room);
			}
			
		} catch (SQLException e) {
//			log.error(e);
			throw new HMSException("Unable To Fetch roomdets");
		}
		return roomList;
	}
	@Override
	public List<User> listUserName(int hcode) throws HMSException {
		List<User> userList;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn.prepareStatement(IQueryMapper.FIND_USER);)  {
			st.setInt(1, hcode);
			ResultSet rs = st.executeQuery();
			
			userList = new ArrayList<User>();
			while(rs.next()){
				User user = new User();
				
				user.setUserName(rs.getString("username"));
				System.out.println(user.getUserId());
				userList.add(user);
			}
			
		} catch (SQLException e) {
//			log.error(e);
			throw new HMSException("Unable To Fetch username");
		}
		return userList;
	}
	@Override
	public List<Booking> listBooking(int hcode) throws HMSException {
		List<Booking> bookingList;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn.prepareStatement(IQueryMapper.LIST_BOOKING_DETAILS);)  {
			st.setInt(1, hcode);
			ResultSet rs = st.executeQuery();
			
			bookingList = new ArrayList<Booking>();
			while(rs.next()){
				Booking book = new Booking();
				
				book.setBookingId(rs.getInt("bookingid"));
				book.setRoomId(rs.getInt("roomid"));
				book.setUserId(rs.getInt("userid"));
				bookingList.add(book);
			}
			
		} catch (SQLException e) {
//			log.error(e);
			throw new HMSException("Unable To Fetch username");
		}
		return bookingList;
	}
	
}
